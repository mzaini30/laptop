<div>
    {{-- Nothing in the world is as soft and yielding as water. --}}
    <a href="/guest" hx-boost="true" class="bg-blue-800 rounded shadow text-white py-3 px-6 inline-block">Pendaftaran</a>
</div>
