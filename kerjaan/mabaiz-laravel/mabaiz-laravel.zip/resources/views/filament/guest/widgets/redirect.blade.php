<x-filament-widgets::widget>
    <x-filament::section>
        {{-- Widget content --}}
        @script
            <script>
                location.href = "/guest/registers/create"
            </script>
        @endscript
    </x-filament::section>
</x-filament-widgets::widget>
