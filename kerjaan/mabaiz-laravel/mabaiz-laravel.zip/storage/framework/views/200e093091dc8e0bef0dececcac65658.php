<div>
    
    <a href="/guest" hx-boost="true" class="bg-blue-800 rounded shadow text-white py-3 px-6 inline-block">Pendaftaran</a>
</div>
<?php /**PATH G:\zen\kerjaan\mabaiz-laravel\resources\views/livewire/tombol-pendaftaran.blade.php ENDPATH**/ ?>