<?php $__env->startSection('title', 'Program Unggulan Madrasah Baitul Izzah'); ?>

<div>
    
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('navbar', []);

$__html = app('livewire')->mount($__name, $__params, 'onBIIzb', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php $data_program = [['foto' => '/gambar/percakapan.jpeg', 'judul' => 'Bahasa Arab', 'keterangan' => 'Percakapan bahasa Arab sehari-hari'], ['foto' => '/gambar/camping.jpeg', 'judul' => 'Kegiatan Fisik', 'keterangan' => 'Berenang, memanah, dan bermain bola'], ['foto' => '/gambar/komputer.jpeg', 'judul' => 'Keterampilan Komputer', 'keterangan' => 'Menguasai dasar-dasar mengetik 10 jari dan Microsoft Office'], ['foto' => '/gambar/belajar.jpg', 'judul' => 'Pelajaran Diniyah', 'keterangan' => 'Membekali santri dengan ilmu-ilmu agama'], ['foto' => '/gambar/murojaah.jpg', 'judul' => 'Tahfidz Quran', 'keterangan' => 'Menghapal Quran dalam waktu 3 tahun dengan fokus pada kelancaran hapalan']]; ?>
    <div class="px-[10%] py-[7.5rem] grid grid-cols-1 sm:grid-cols-2 gap-5">
        <?php foreach($data_program as $x): ?>
        <div class="bg-white flex w-full shadow border rounded overflow-hidden">
            <img src="<?= $x['foto'] ?>" class="w-40 aspect-square object-cover" alt="">
            <div class="p-3 flex items-center">
                <div>
                    <p class="font-bold text-xl pb-2">
                        <?= $x['judul'] ?>
                    </p>
                    <p>
                        <?= $x['keterangan'] ?>
                    </p>
                </div>
            </div>
        </div>
        <?php endforeach ?>
    </div>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('footer', []);

$__html = app('livewire')->mount($__name, $__params, 'CAfPgXr', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
</div>
<?php /**PATH G:\zen\kerjaan\mabaiz-laravel\resources\views/livewire/program.blade.php ENDPATH**/ ?>