<?php

namespace App\Filament\Guest\Widgets;

use Filament\Widgets\Widget;

class Redirect extends Widget
{
    protected static string $view = 'filament.guest.widgets.redirect';
}
