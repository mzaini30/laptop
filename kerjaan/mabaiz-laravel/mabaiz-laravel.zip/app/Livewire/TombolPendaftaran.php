<?php

namespace App\Livewire;

use Livewire\Component;

class TombolPendaftaran extends Component
{
    public function render()
    {
        return view('livewire.tombol-pendaftaran');
    }
}
