# Laci

## Cara Pakai

```
[laci judulnya="Ini adalah judul"]
Ini adalah isi
[/laci]
```