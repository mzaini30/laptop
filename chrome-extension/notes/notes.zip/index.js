open("https://kumpulan-tools.github.io/aplikasi/notes/", "_blank");
