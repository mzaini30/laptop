open("https://kumpulan-tools.github.io/aplikasi/penilaian-hadits/", "_blank");
